This is a random password generator

![Optional Text](Capture.jpg)

